from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/voltage-drop", methods=["GET", "POST"])
def voltage_drop():
    result = None
    if request.method == "POST":
        voltage = float(request.form.get("voltage", 0))
        current = float(request.form.get("current", 0))
        length = float(request.form.get("length", 0))
        pf = float(request.form.get("pf", 1))
        vd_allowed = float(request.form.get("vdAllowed", 3))

        resistance = 0.018  # Ohm/m (placeholder)
        reactance = 0.015   # Ohm/m (placeholder)
        vd = (current * (resistance * length * pf + reactance * length * (1 - pf))) / voltage * 100

        result = f"Queda de tensão = {vd:.2f}% (Permitida: {vd_allowed}%)"

    return render_template("voltage_drop.html", result=result)

@app.route("/conduit-dimension")
def conduit():
    return render_template("conduit.html")

@app.route("/cable-tray-sizing")
def cable_tray():
    return render_template("cable_tray.html")

@app.route("/others")
def others():
    return render_template("others.html")

if __name__ == "__main__":
    app.run(debug=True)
